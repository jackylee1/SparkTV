Team Typer
Team members:  Emily Hua (yh2901), Guanlin Zhou (gz2250), Tongyun Wu(tw2568), Ming Zhou (mz2591), Zhi Zheng (zz2406)

done:
error code: API gateway configure error code regex and integration response body mapping template 
barcode generation from calling smarty street
autocomplete using jQuery 

not done yet:
POST to db from front end 
update addresses through smarty street validation 



